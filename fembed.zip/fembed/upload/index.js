const fs = require('fs')
const tus = require('tus-js-client')
const axios = require('axios')
const request = require('request')
const progress = require('request-progress')
const pathFile = require('path')
const mimeTypes = require('mime-types')
const md5 = require('md5')

const Drive = require('../models/drive')
const Auth = require('../models/auth')
const Message = require('../models/message')
const { addDownload, getAccessToken, setDownload,
    isDownloaded, getAuth, checkJson, getFingerprint } = require('../helpers')
// Public fuction loop
var checkStatusInt;
var requestTaskInt;
module.exports = {
    async loopTool() {
        var wait = fs.readFileSync('./logs/wait.json', { encoding: 'utf8' })
        wait = JSON.parse(wait)
        if (wait.length === 0) {
            console.log('changed to reupload mode!')
            module.exports.clearLoop()
            checkStatusInt = setInterval(() => {
                module.exports.checkStatusAll()
            }, 10000)
        } else {
            if (!requestTaskInt) {
                console.log('changed to upload mode!')
                module.exports.clearLoop()
                requestTaskInt = setInterval(() => {
                    module.exports.sendTask()
                }, 10000)
            }
        }
    },
    async clearLoop() {
        clearInterval(checkStatusInt)
        clearInterval(requestTaskInt)
        checkStatusInt = null
        requestTaskInt = null
    },
    async addWait(drive_id, fileName, mimeType) {
        try {
            var curWait = fs.readFileSync('./logs/wait.json', 'utf8')
            var json = JSON.parse(curWait)
            json.push({ drive_id, fileName, mimeType })
            fs.writeFileSync('./logs/wait.json', JSON.stringify(json), 'utf8')
        } catch (err) {
            fs.appendFileSync('./logs/errors.log', `${new Date} ${err.message} at AddWait function.\n`, { encoding: 'utf8' });
        }
    },
    async sendTask() {
        try {
            var curWait = fs.readFileSync('./logs/wait.json', 'utf8')
            var waits = JSON.parse(curWait)
            if (waits.length === 0) return;
            var curDown = fs.readFileSync('./logs/download.json', 'utf8')
            var downloads = JSON.parse(curDown)
            if (downloads.length > 0) return;
            var { drive_id, fileName, mimeType } = waits[0]
            fileName = md5(fileName)
            module.exports.startUpload(drive_id, fileName, mimeType)
            waits.splice(0, 1)
            fs.writeFileSync('./logs/wait.json', JSON.stringify(waits), 'utf8')
            console.log('A task ' + drive_id + ' going...')
        } catch (err) {
            fs.appendFileSync('./logs/errors.log', `${new Date} ${err.message}\n`, { encoding: 'utf8' })
        }
    },
    async startUpload(drive_id, fileName, mimeType) {
        try {
            console.log('Start task...')
            if (!pathFile.extname(fileName)) {
                fileName = mimeTypes.extension(mimeType)
            }
            await module.exports.downloadDrive(drive_id, fileName, mimeType)
            await module.exports.uploadToHost(drive_id, fileName, mimeType)
            await module.exports.deleteFile(drive_id, fileName, mimeType)
        } catch (err) {
            await module.exports.deleteFile(drive_id, fileName, mimeType)
            fs.appendFileSync('./logs/errors.log', `${new Date} ${err.message}\n`, { encoding: 'utf8' });
        }
    },
    async resumeDownload() {
        try {
            var downloading = fs.readFileSync('./logs/download.json', 'utf8')
            var downloads = JSON.parse(downloading)
            if (downloads.length < 1) return;
            for (var download of downloads) {
                var { drive_id, fileName, mimeType } = download
                fileName = md5(fileName)
                module.exports.startUpload(drive_id, fileName, mimeType)
            }
        } catch (err) {
            fs.appendFileSync('./logs/errors.log', `${new Date} ${err.message}\n`, { encoding: 'utf8' });
        }
    },
    async checkStatusAll() {
        try {
            var count = await Drive.countDocuments({ status: 1 })
            var random = Math.floor(Math.random() * count)
            var drive = await Drive.findOne({ status: 1 }).skip(random)
            if (!drive) return;
            var { drive_id, name, mimeType, data } = drive
            var { id, auth } = data
            var authT = await Auth.findOne({ client_id: auth })
            if (authT) {
                var { client_id, token } = authT
                var url = 'https://www.fembed.com/api/file'
                var data = `client_id=${client_id}&client_secret=${token}&file_id=${id}`
                var geturl = await axios.post(url, data, {
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded'
                    }
                })
                var { data, success } = geturl.data
                if (!success || data.status === "Removed") {
                    console.log('reupload %s', drive_id)
                    await Drive.updateOne({ drive_id }, { status: 0 })
                    module.exports.addWait(drive_id, name, mimeType)
                }
            }
        } catch (err) {
            fs.appendFileSync('./logs/errors.log', `${new Date} ${err.message}\n`, { encoding: 'utf8' });
        }
    },
    async downloadDrive(drive_id, fileName, mimeType) {
        var drive = await Drive.findOne({ drive_id })
        var dir = `./files`
        var isDown = await isDownloaded(drive_id, fileName, mimeType)
        return new Promise(async (resolve, reject) => {
            try {
                if (drive.status === 1) {
                    throw Error(`${drive_id} failed to download. This file is uploaded.`)
                }
                if (isDown) {
                    return resolve()
                }
                // Add cookie downloading
                await addDownload(drive_id, fileName, mimeType)
                var access_token = await getAccessToken()
                options = {
                    url: 'https://www.googleapis.com/drive/v3/files/' + drive_id + '?alt=media',
                    method: 'GET',
                    headers: {
                        'Authorization': 'Bearer ' + access_token
                    }
                }
                // Download
                console.log(`Downloading ${drive_id}`)
                progress(request(options), {
                }).on('progress', function (state) {
                    // console.log('downloading %j %', state.percent * 100)
                }).on('error', async function (err) {
                    await Drive.updateOne({ drive_id }, { status: 2 })
                    throw Error(`${drive_id} Downloaded fail. Error: ${err.message}`)
                }).on('end', async function () {
                    console.log('Download completed.')
                    await setDownload(drive_id, fileName, mimeType)
                    return resolve()
                }).pipe(fs.createWriteStream(`${dir}/${fileName}`))

            } catch (err) {
                await Message.create({ message: err.message, error: true })
                return reject(new Error(err.message))
            }
        })
    },
    async uploadToHost(drive_id, fileName, mimeType) {
        var drive = await Drive.findOne({ drive_id })
        return new Promise(async (resolve, reject) => {
            try {
                if (drive.status === 1) return resolve()
                var dir = `./files`
                var path = `${dir}/${fileName}`
                if (!fs.existsSync(path)) throw Error("Not file found.")
                var pathUpload = fs.createReadStream(path)
                var fileSize = (fs.statSync(path)).size
                var { auth, checkAuth } = await getAuth()
                if (!checkAuth) throw Error("Failed to upload " + drive_id + ". Can't get url upload from api.")
                var { token, url } = checkAuth.data
                var upload = new tus.Upload(pathUpload, {
                    fid: null,
                    chunkSize: 5 * 1024 * 1024,
                    endpoint: url,
                    retryDelays: [0, 3000, 5000, 10000, 20000],
                    uploadSize: fileSize,
                    metadata: {
                        name: `${fileName}.mp4`,
                        token: token
                    },
                    onError: async function (error) {
                        console.error(error)
                        var err = "Failed to upload " + drive_id + ". Can't upload. file too small. Maybe they are maintenancing."
                        await Message.create({ message: err, error: true })
                        await Drive.updateOne({ drive_id }, { status: 2 })
                        return reject(new Error(err))
                    },
                    onProgress: function (bytesUploaded, bytesTotal) {
                        var percentage = (bytesUploaded / bytesTotal * 100).toFixed(0)
                        console.log(`Uploading fembed... ${percentage} %`)
                    },
                    onSuccess: async function () {
                        var finger = upload.url.split('/').slice(4)
                        setTimeout(async () => {
                            var getId = await getFingerprint(auth, finger)
                            var { client_id } = auth
                            var id = getId.data
                            var domain = "fembed.com"
                            var base = "//fembed.com/"
                            var url = base + "v/" + id
                            await Drive.updateOne({ drive_id }, { data: { domain, id, url, auth: client_id }, status: 1 })
                            await Message.create({ message: "Your file " + drive_id + " has been upload success." })
                            console.log('Upload ' + drive_id + ' completed.')
                            return resolve()
                        }, 20000)
                    }
                })
                // Start the upload
                upload.start()

            } catch (err) {
                await Message.create({ message: err.message, error: true })
                await Drive.updateOne({ drive_id }, { status: 2 })
                return reject(new Error(err.message))
            }
        })
    },
    async deleteFile(drive_id, fileName, mimeType) {
        return new Promise(async (resolve, reject) => {
            try {
                var dir = `./files`
                var path = `${dir}/${fileName}`
                var file = await fs.existsSync(path)
                if (file) {
                    await fs.unlinkSync(path)            
                }
                // Check cookie and delete
                var currDownload = fs.readFileSync('./logs/download.json', 'utf8')
                var json = JSON.parse(currDownload)
                var isHas = json.filter(x => x.drive_id === drive_id)[0]
                if (isHas) {
                    var index = json.findIndex(x => x.drive_id === drive_id)
                    json.splice(index, 1)
                    fs.writeFileSync('./logs/download.json', JSON.stringify(json), 'utf8')
                }
                return console.log('a file has deleted by system because upload completed.')
            } catch (err) {
                fs.appendFileSync('./logs/errors.log', `${new Date} ${err.message}\n`, { encoding: 'utf8' });
            }
        })
    }
}