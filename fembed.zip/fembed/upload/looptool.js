const fs = require('fs')
const { resumeDownload, loopTool } = require('./index')
var dir = `./files`
if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir);
}

resumeDownload()
loopTool()
fs.watchFile('./logs/wait.json', async () => {
    loopTool()
});