const { Router } = require('express')
const route = Router()
const fs = require('fs')
const path = require('path')
const multer = require('multer')
const moment = require('moment')
const ExpressBrute = require('express-brute')
const store = new ExpressBrute.MemoryStore()

var failCallback = function (req, res, next, nextValidRequestDate) {
    var error = "You've made too many failed attempts in a short period of time, please try again " + moment(nextValidRequestDate).fromNow() + ""
   return res.status(403).send({ success: false, error })
};
var handleStoreError = function (error) {
    throw {
        message: error.message,
        parent: error.parent
    };
}

var userBruteforce = new ExpressBrute(store, {
    freeRetries: 5,
    minWait: 5 * 60 * 1000, // 5 minutes
    maxWait: 60 * 60 * 1000, // 1 hour,
    failCallback: failCallback,
    handleStoreError: handleStoreError
})


const { removeAuth, uploadCre, removeCre,
    removeOauth, activeOauths, removeData } = require('../controllers/client')
// Get
const { getAuth, getCredentials, getHome, getOauths,
    getSingleFile, getFolder, getManyFile, getDatas, getSignIn, getApiPage, getErrors } = require('../controllers/client')
// Set
const { setAuth, setFolder, setManyFile, setSingleFile,
    exportData, signIn, reUploadData, addOauth, signOut, reUploadAllData } = require('../controllers/client')
// Midd
const { isSignIn, isSignInPost } = require('../middlewares/auth')

var storage = multer.diskStorage({
    destination: '.credentials/',
    filename: function (req, file, cb) {
        cb(null, file.originalname);
    }
});

var upload = multer({
    fileFilter: function (req, file, callback) {
        var dir = './.credentials'
        var folder = fs.readdirSync(dir)
        if (folder.length > 0) {
            return callback(new Error('You already has a credenticals. Remove fisrt if you want add other.'))
        }
        var ext = path.extname(file.originalname);
        if (ext !== '.json') {
            return callback(new Error('Only json file are allowed!'))
        }
        callback(null, true)
    },
    limits: {
        fileSize: 1024 * 1024
    },
    storage: storage
})

//get
route.get('/', isSignIn, getHome)
route.get('/errors', isSignIn, getErrors)
route.get('/datas', isSignIn, getDatas)
route.get('/api', isSignIn, getApiPage)
route.get('/credential', isSignIn, getCredentials)
route.get('/oauths', isSignIn, getOauths)
route.get('/authorizations', isSignIn, getAuth)
route.get('/add-new', isSignIn, getSingleFile)
route.get('/add-many', isSignIn, getManyFile)
route.get('/add-folder', isSignIn, getFolder)
route.get('/sign-in', getSignIn)
route.post('/sign-in', userBruteforce.prevent, upload.none(), signIn)
route.post('/sign-out', isSignInPost, signOut)
// post
route.post('/add-file', isSignInPost, upload.none(), setSingleFile)
route.post('/add-many', isSignInPost, upload.none(), setManyFile)
route.post('/add-folder', isSignInPost, upload.none(), setFolder)

route.post('/add-auth', isSignInPost, upload.none(), setAuth)
route.post('/add-oauth', isSignInPost, upload.none(), addOauth)
route.post('/export-data', isSignInPost, upload.none(), exportData)

route.put('/reupload-data', isSignInPost, upload.none(), reUploadData)
route.put('/active-oauths', isSignInPost, upload.none(), activeOauths)
route.put('/reupload-all-data', isSignInPost, upload.none(), reUploadAllData)
// delete
route.delete('/remove-auth', isSignInPost, upload.none(), removeAuth)
route.delete('/remove-cre', isSignInPost, upload.none(), removeCre)
route.delete('/remove-oauth', isSignInPost, upload.none(), removeOauth)
route.delete('/remove-data', isSignInPost, upload.none(), removeData)
// Upload
route.post('/upload-cre', isSignInPost, uploadCre, upload.any(), async (req, res) => {
    try {
        if (req.files.length === 0) throw Error("Not file found.")
        var dir = './.credentials'
        var folder = fs.readdirSync(dir)
        if (folder.length > 0) {
            var credentials = fs.readFileSync(`${dir}/${folder[0]}`, { encoding: 'utf8' })
            credentials = JSON.parse(credentials)
        } else {
            var credentials = {}
        }
        res.send({
            success: true,
            data: JSON.stringify(credentials, null, 2),
            message: "Success. Your credentials has saved."
        })
    } catch (err) {
        res.status(403).send({ success: false, error: err.message })
    }
})

module.exports = route