const { Router } = require('express')
const route = Router()
const { getDatas, checkStatus, getToken } = require('../controllers/api')
const { setSingleFile, setFolder, setManyFile } = require('../controllers/client')
const { isSignInApi } = require('../middlewares/auth')
// delete

route.get('/check-status', checkStatus)
route.get('/v1/get-datas/:drive_id', isSignInApi, getDatas)
route.get('/v1/get-token', getToken)

route.get('/v1/add-file', isSignInApi, setSingleFile)
route.get('/v1/add-many', isSignInApi, setManyFile)
route.get('/v1/add-folder', isSignInApi, setFolder)
module.exports = route