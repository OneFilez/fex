function timeDifference(current, previous) {
    var msPerMinute = 60 * 1000;
    var msPerHour = msPerMinute * 60;
    var msPerDay = msPerHour * 24;
    var msPerMonth = msPerDay * 30;
    var msPerYear = msPerDay * 365;

    var elapsed = current - previous;

    if (elapsed < msPerMinute) {
        return Math.round(elapsed / 1000) + ' seconds ago';
    }
    else if (elapsed < msPerHour) {
        return Math.round(elapsed / msPerMinute) + ' minutes ago';
    }
    else if (elapsed < msPerDay) {
        return Math.round(elapsed / msPerHour) + ' hours ago';
    }
    else if (elapsed < msPerMonth) {
        return 'approximately ' + Math.round(elapsed / msPerDay) + ' days ago';
    }
    else if (elapsed < msPerYear) {
        return 'approximately ' + Math.round(elapsed / msPerMonth) + ' months ago';
    }
    else {
        return 'approximately ' + Math.round(elapsed / msPerYear) + ' years ago';
    }
}



function encodeQueryData(data) {
    const ret = [];
    for (let d in data)
        ret.push(encodeURIComponent(d) + '=' + encodeURIComponent(data[d]));
    return ret.join('&');
}

function snackBar(bl, string) {
    var x = document.getElementById("snackbar");
    x.innerHTML = string
    var istrue = bl ? '' : 'error'
    x.className = `show ${istrue}`;
    setTimeout(function () { x.className = x.className.replace(`show ${istrue}`, ""); }, 5000);
}

function getCookie(cookie, name) {
    var value = "; " + cookie;
    var parts = value.split("; " + name + "=");
    if (parts.length == 2) return parts.pop().split(";").shift();
}

function checkEmail(email) {
    var valid = RegExp(/^[a-z][a-z0-9_\.]{5,32}@[a-z0-9]{2,}(\.[a-z0-9]{2,4}){1,2}$/gm)
    return valid.test(email)
}

function urlValid(text) {
    var regExp = RegExp(/^(http:\/\/www\.|https:\/\/www\.|http:\/\/|https:\/\/)[a-z0-9]+([\-\.]{1}[a-z0-9]+)*\.[a-z]{2,5}(:[0-9]{1,5})?(\/.*)?$/)
    var valid = regExp.test(text);
    return valid
}

function getDriveId(url) {
    var regExp = /(?:https?:\/\/)?(?:[\w\-]+\.)*(?:drive|docs)\.google\.com\/(?:(?:open|uc)\?(?:[\w\-\%]+=[\w\-\%]*&)*id=|(?:folder|file)\/d\/|\/ccc\?(?:[\w\-\%]+=[\w\-\%]*&)*key=)([\w\-]{28,})/i;
    var match = url.match(regExp);
    if (!match) {
        return url;
    }
    return match[1];
}

function oauthCallback(client_id, redirect_uri, auth_uri) {
    console.log(client_id, redirect_uri, auth_uri)
    var scope = "https://www.googleapis.com/auth/drive";
    var response_type = "code";
    var access_type = "offline";
    var query = encodeQueryData({
        access_type,
        scope,
        response_type,
        client_id,
        redirect_uri
    });
    return window.open(auth_uri + "?" + query, "_blank");
}

function activeOauthCallback(index, email, client_id, client_secret, redirect_uri) {
    var code = $("#token-oauth-input-" + index).val();
    var grant_type = "authorization_code";
    var base = "https://accounts.google.com/o/oauth2/token";
    var formData = new FormData();
    formData.append("code", code);
    formData.append("client_id", client_id);
    formData.append("client_secret", client_secret);
    formData.append("grant_type", grant_type);
    formData.append("redirect_uri", redirect_uri);
    var request = $.ajax({
        url: base,
        method: 'POST',
        data: formData,
        contentType: false,
        processData: false
    })
    request.done(function (oauths) {
        var formData = new FormData();
        formData.append("email", email);
        formData.append("oauths", JSON.stringify(oauths));
        var request = $.ajax({
            url: 'active-oauths',
            method: 'PUT',
            data: formData,
            contentType: false,
            processData: false
        })
        request.done(function (resp) {
            location.reload(true)
        }).fail(function (data) {
            snackBar(false, data.responseJSON.error)
        })
    }).fail(function (data) {
        snackBar(false, data.responseJSON.error)
    })
}

function apiCallbackRefresh(url, method, formData, disabled) {
    if (disabled) {
        $(disabled).prop('disabled', true);
    }
    var request = $.ajax({
        url,
        method,
        data: formData,
        contentType: false,
        processData: false
    })
    request.done(function (resp) {
        location.reload(true)
    }).fail(function (data) {
        if (disabled) {
            $(disabled).prop("disabled", false)
        }
        snackBar(false, data.responseJSON.error)
    })
}

function apiCallbackwithoutRefresh(url, method, formData, disabled) {
    if (disabled) {
        $(disabled).prop('disabled', true);
    }
    var request = $.ajax({
        url,
        method,
        data: formData,
        contentType: false,
        processData: false
    })
    request.done(function (resp) {
        if (disabled) {
            $(disabled).prop("disabled", false)
        }
        snackBar(true, resp.message)
    }).fail(function (data) {
        if (disabled) {
            $(disabled).prop("disabled", false)
        }
        snackBar(false, data.responseJSON.error)
    })
}

