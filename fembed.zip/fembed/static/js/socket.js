// call socket
var socket = io("/")
$(document).ready(function () {
  var pathname = window.location.pathname;
  $('#svSettings a[href="' + pathname + '"]').parent().parent().addClass('show');
  $('#svSettings a[href="' + pathname + '"]').addClass('active');
  $('#collapsePages a[href="' + pathname + '"]').parent().parent().addClass('show');
  $('#collapsePages a[href="' + pathname + '"]').addClass('active');
  $('.nav-item a[href="' + pathname + '"]').parent().addClass('active');
  // call message
  socket.emit("message");
  socket.on("send-message", ({ data, total }) => {
    if (data) {
      var totalItem = document.getElementById('alert-total');
      if (total > 6) {
        total = '6+'
      }
      totalItem.innerText = total;
      var list = document.getElementById('alert-message');
      var listItem = '<h6 class="dropdown-header">Alerts Center</h6>';
      $.each(data, function (key, item) {
        var error = item.error
        var dateStr = timeDifference(Date.now(), item.created_at)
        listItem += `<a class="dropdown-item d-flex align-items-center text-break" href="/datas">
            <div class="mr-3">
              <div class="icon-circle ${error ? 'bg-danger' : 'bg-primary'}">
                <i class="fas ${error ? 'fa-exclamation-triangle' : 'fa-file-alt'} text-white"></i>
              </div>
            </div>
            <div>
              <div class="small text-gray-500">${dateStr}</div>
              <span class="font-weight-bold">${item.message}</span>
            </div>
          </a>`;
      });
      listItem += '<a onclick="removeAllMessage()" class="dropdown-item text-center small text-gray-500" href="#">Clear All Alerts</a>'
      list.innerHTML = listItem;
    }
  });

  $('#sign-out').on('click', function () {
    var request = $.ajax({
      url: 'sign-out',
      method: 'POST',
      contentType: false,
      processData: false
    })
    request.done(function (resp) {
      window.location.replace("/sign-in");
    }).fail(function (data) {
      var error = data.responseJSON ? data.responseJSON.error : data.statusText
      snackBar(false, error)
    })
  })

  $('#inputGroupFile01').on('change', function () {
    var fileName = $(this).val().split("\\").pop();;
    $(this).next('.custom-file-label').html(fileName);
  })

  $('#submit-cre').on('click', function () {
    var input = document.getElementById('inputGroupFile01');
    var formData = new FormData();
    formData.append("file", input.files[0] || '');
    var request = $.ajax({
      url: 'upload-cre',
      method: 'post',
      data: formData,
      contentType: false,
      processData: false
    })
    request.done(function (resp) {
      var creData = document.getElementById('credential-data')
      creData.innerHTML = resp.data
      snackBar(true, resp.message)
    }).fail(function (data) {
      snackBar(false, data.responseJSON.error)
    })
  })

  $('#remove-cre').on('click', function () {
    var request = $.ajax({
      url: 'remove-cre',
      method: 'DELETE',
      contentType: false,
      processData: false
    })
    request.done(function (data) {
      var creData = document.getElementById('credential-data')
      creData.innerHTML = "{}"
      snackBar(true, data.message)
    }).fail(function (data) {
      snackBar(false, data.responseJSON.error)
    })
  })

})

function removeAllMessage() {
  socket.emit("remove-message");
  snackBar(true, "Success. Your has removed all alert!")
}