const fs = require('fs')
const axios = require('axios')
const jwt = require('jsonwebtoken')
const Drive = require('../models/drive')
const Oauths = require('../models/oauths')
const Auth = require('../models/auth')
const { getAccessToken } = require('../helpers')
const { addWait } = require('../upload')
const { urlValid, getDriveId } = require('../helpers')

function jwtSignKey(key) {
    return jwt.sign({ secret_key: key }, process.env.JWTSECRET, {
        expiresIn: "7d"
    })
}

// Export Module
module.exports = {
    // Other
    async getApiPage(req, res) {
        var { access_token } = req.signedCookies
        res.render('func/api', {
            pageTitle: 'Fembed - Api',
            data: access_token,
            message: req.flash()
        })
    },
    // Login
    async getSignIn(req, res) {
        res.render('sign-in', {
            pageTitle: 'Fembed - Sign In',
            message: req.flash(),
            layout: 'layoutsign'
        })
    },
    async signIn(req, res) {
        try {
            var { key } = req.body
            if (!key || key !== process.env.ACCESS_KEY) throw Error('Secret key invalid.')
            var token = jwtSignKey(key)
            res.cookie('access_token', token, {
                signed: true,
                httpOnly: true,
                expires: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000)
            });
            return res.redirect('/')
        } catch (err) {
            res.status(403).send({ success: false, error: err.message })
        }
    },
    async signOut(req, res) {
        try {
            res.clearCookie("access_token");
            return res.redirect('/sign-in')
        } catch (err) {
            res.status(403).send({ success: false, error: err.message })
        }
    },
    // Home
    async getHome(req, res) {
        var file_added = await Drive.countDocuments()
        var file_progress = await Drive.countDocuments({ status: 0 })
        var file_uploaded = await Drive.countDocuments({ status: 1 })
        var file_error = await Drive.countDocuments({ status: 2 })
        var data = { file_added, file_progress, file_uploaded, file_error }
        res.render('index', {
            pageTitle: 'Fembed - Upload tool',
            message: req.flash(),
            data
        })
    },
    // Datas
    async getDatas(req, res) {
        try {
            var page = parseInt(req.query.page || 1)
            var perPage = parseInt(req.query.limit || 12)
            // Pagination Area

            var total = await Drive.countDocuments()
            var query = Drive.find({}, { __v: 0, _id: 0 })
            var datas = await query.skip((page - 1) * perPage).limit(perPage).sort({ created_at: -1 })
            var totalPage = Math.ceil(total / perPage)
            // Search Area
            var search = req.query.q
            if (search) {
                function escapeRegex(text) {
                    return text.replace(/[-[\]{}()*+?.,\\^$|#\s]/g, "\\$&")
                }
                var regex = new RegExp(escapeRegex(search), 'gi')
                total = await Drive.countDocuments({ $or: [{ name: regex }, { drive_id: search }] })
                query = Drive.find({ $or: [{ name: regex }, { drive_id: search }] })
                datas = await query.skip((page - 1) * perPage).limit(perPage)
                totalPage = Math.ceil(total / perPage)
                req.flash('success', 'Result of ' + search)
            }
            res.render('func/datas', {
                req,
                pageTitle: 'Fembed - Datas',
                message: req.flash(),
                data: datas,
                meta: { page, perPage, totalPage }
            })
        } catch (err) {
            req.flash('errors', err.message)
            return res.redirect('/')
        }
    },
    async getErrors(req, res) {
        try {
            var page = parseInt(req.query.page || 1)
            var perPage = parseInt(req.query.limit || 12)
            // Pagination Area

            var total = await Drive.countDocuments({ status: 2 })
            var query = Drive.find({
                $or: [{ status: 2 },
                {
                    "progress.downloaded": true,
                    "progress.rendered": true,
                    "progress.end_worker": { $ne: true }
                }]
            }, { __v: 0, _id: 0 })
            var errors = await query.skip((page - 1) * perPage).limit(perPage).sort({ created_at: -1 })
            var totalPage = Math.ceil(total / perPage)
            // Search Area
            var search = req.query.q
            if (search) {
                function escapeRegex(text) {
                    return text.replace(/[-[\]{}()*+?.,\\^$|#\s]/g, "\\$&")
                }
                var regex = new RegExp(escapeRegex(search), 'gi')
                total = await Drive.countDocuments({ status: 2, $or: [{ name: regex }, { drive_id: search }] })
                query = Drive.find({ status: 2, $or: [{ name: regex }, { drive_id: search }] })
                errors = await query.skip((page - 1) * perPage).limit(perPage)
                totalPage = Math.ceil(total / perPage)
                req.flash('success', 'Result of ' + search)
            }
            res.render('func/errors', {
                req,
                pageTitle: 'Fembed - Errors',
                message: req.flash(),
                data: errors,
                meta: { page, perPage, totalPage }
            })
        } catch (err) {
            req.flash('errors', err.message)
            return res.redirect('/')
        }
    },
    async reUploadData(req, res) {
        try {
            var { drive_id } = req.body
            var isHas = await Drive.findOne({ drive_id })
            if (isHas) {
                await Drive.updateOne({ drive_id }, { status: 0 })
                var { drive_id, name, mimeType } = isHas
                addWait(drive_id, name, mimeType)
                req.flash('success', 'Success. File: ' + drive_id + ' reuploading.')
                return res.send({ success: true, message: "Success. You reupload " + drive_id })
            } else {
                throw Error("Not file found.")
            }
        } catch (err) {
            res.status(403).send({ success: false, error: err.message })
        }
    },
    async reUploadAllData(req, res) {
        try {
            var drives = await Drive.find({
                $or: [{ status: 2 },
                {
                    "progress.downloaded": true,
                    "progress.rendered": true,
                    "progress.end_worker": { $ne: true }
                }]
            })
            if (drives.length > 0) {
                for (var drive of drives) {
                    var { drive_id, name, mimeType } = drive
                    await Drive.updateOne({ drive_id }, { status: 0 })
                    addWait(drive_id, name, mimeType)
                }
                return res.send({
                    success: true,
                    message: 'Success. You reuploading ' + drives.length + ' files.'
                })
            } else {
                throw Error("Not file error found.")
            }
        } catch (err) {
            res.status(403).send({ success: false, error: err.message })
        }
    },
    async exportData(req, res) {
        try {
            var data = await Drive.find({}, { _id: 0, __v: 0 })
            res.send(data);
        } catch (err) {
            res.status(403).send({ success: false, error: err.message })
        }
    },
    async removeData(req, res) {
        try {
            var { drive_id } = req.body
            var isHas = await Drive.findOne({ drive_id })
            if (isHas) {
                await Drive.deleteOne({ drive_id })
                req.flash('success', 'Success. File: ' + drive_id + ' has deleted.')
                return res.send({ success: true, message: "Success. You deleted " + drive_id })
            } else {
                throw Error("Not file found.")
            }
        } catch (err) {
            res.status(403).send({ success: false, error: err.message })
        }
    },
    // Credentials
    async getCredentials(req, res) {
        var dir = './.credentials'
        var folder = fs.readdirSync(dir)
        if (folder.length > 0) {
            var credentials = fs.readFileSync(`${dir}/${folder[0]}`, { encoding: 'utf8' })
            credentials = JSON.parse(credentials)
        } else {
            var credentials = {}
        }
        res.render('func/credential', {
            pageTitle: 'Fembed - Credentical',
            message: req.flash(),
            data: JSON.stringify(credentials, null, 2)
        })
    },
    async uploadCre(req, res, next) {
        try {
            return next()
        } catch (err) {
            res.status(403).send({ success: false, error: err.message })
        }
    },
    async removeCre(req, res, next) {
        try {
            var dir = './.credentials'
            var folder = fs.readdirSync(dir)
            if (folder.length > 0) {
                var path = `${dir}/${folder[0]}`
                fs.unlinkSync(path)
            }
            res.send({ success: true, message: "Success. You deleted!" })
        } catch (err) {
            res.status(403).send({ success: false, error: err.message })
        }
    },
    // Oauth
    async getOauths(req, res) {
        var page = parseInt(req.query.page || 1)
        var perPage = parseInt(req.query.limit || 12)
        // Pagination Area
        var total = await Oauths.countDocuments()
        var query = Oauths.find({}, { __v: 0, _id: 0, oauths: 0 })
        var oauths = await query.skip((page - 1) * perPage).limit(perPage)
        var totalPage = Math.ceil(total / perPage);
        // Creden
        var dir = './.credentials'
        var folder = fs.readdirSync(dir)
        if (folder.length > 0) {
            var credentials = fs.readFileSync(`${dir}/${folder[0]}`, { encoding: 'utf8' })
            credentials = JSON.parse(credentials)
        } else {
            var credentials = {}
        }
        res.render('func/oauths', {
            req,
            pageTitle: 'Fembed - Oauths',
            message: req.flash(),
            data: { oauths, credentials },
            meta: { page, perPage, totalPage }
        })
    },
    async addOauth(req, res) {
        try {
            var { email } = req.body
            var isHas = await Oauths.findOne({ email })
            if (!email) {
                throw Error("Do not empty field.")
            }
            if (isHas) {
                throw Error("This email already exist.")
            }
            var status = false
            await Oauths.create({ email, status })
            req.flash('success', 'Success.')
            res.redirect('/oauths')
        } catch (err) {
            req.flash('errors', err.message)
            return res.redirect('/oauths')
        }
    },
    async activeOauths(req, res) {
        try {
            var { email, oauths } = req.body
            if (!email || !oauths) throw Error("Not found.")
            var date = new Date()
            oauths = JSON.parse(oauths)
            oauths.expiry_date = date.setSeconds(date.getSeconds() + oauths.expires_in)
            delete oauths.expires_in
            await Oauths.updateOne({ email }, { oauths, status: true })
            req.flash('success', 'Success. You has actived email: ' + email)
            res.send({ success: true, message: 'Success. You has actived email: ' + email })
        } catch (err) {
            res.status(403).send({ success: false, error: err.message })
        }
    },
    async removeOauth(req, res) {
        try {
            var { email } = req.body
            var isHas = await Oauths.findOne({ email })
            if (isHas) {
                await Oauths.deleteOne({ email })
                req.flash('success', 'Success. email: ' + email + ' has deleted.')
                return res.send({ success: true, message: "Success. You deleted " + email })
            } else {
                throw Error("No email found.")
            }
        } catch (err) {
            res.status(403).send({ success: false, error: err.message })
        }
    },
    // Auth (Hosting)
    async getAuth(req, res) {
        try {
            var page = parseInt(req.query.page || 1)
            var perPage = parseInt(req.query.limit || 12)
            // Pagination Area
            var total = await Auth.countDocuments()
            var query = Auth.find()
            var auths = await query.skip((page - 1) * perPage).limit(perPage)
            var totalPage = Math.ceil(total / perPage);
            res.render('func/authorizations', {
                req,
                pageTitle: 'Fembed - Authorizations',
                message: req.flash(),
                data: auths,
                meta: { page, perPage, totalPage }
            })
        } catch (err) {
            req.flash('errors', err.message)
            return res.redirect('/')
        }
    },
    async removeAuth(req, res) {
        try {
            var { auth_id } = req.body
            if (!auth_id) throw Error("Not found.")
            await Auth.deleteOne({ auth_id }, { _id: 0, __v: 0 })
            req.flash('success', 'Success. Your cookie has deleted.')
            res.send({ success: true, message: "Success. You deleted!" })
        } catch (err) {
            res.status(403).send({ success: false, error: err.message })
        }
    },
    async setAuth(req, res) {
        try {
            var { client_id, token } = req.body
            if (!client_id || !token) throw Error("Not found.")
            var isHas = await Auth.findOne({ client_id, token })
            if (isHas) throw Error("Fail. You has added this account.")
            var instance = axios.create({
                baseURL: 'https://www.fembed.com',
                timeout: 10000,
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
            });
            var data = `client_id=${client_id}&client_secret=${token}`
            var checkAuth = await instance.post("/api/account", data)
            if (checkAuth.data.success !== true) throw Error("Api key not valid.")
            await Auth.create({ client_id, token })
            req.flash('success', "Success! You got cookie: " + client_id)
            res.send({ success: true, message: "Success! You got cookie: " + client_id })
        } catch (err) {
            return res.status(403).send({ success: false, error: err.message })
        }
    },
    // Add file
    async getSingleFile(req, res) {
        try {
            res.render('func/add-new', {
                pageTitle: 'Fembed - Add New',
                message: req.flash()
            })
        } catch (err) {
            req.flash('errors', err.message)
            return res.redirect('/')
        }
    },
    async getManyFile(req, res) {
        try {
            res.render('func/add-many', {
                pageTitle: 'Fembed - Add Many',
                message: req.flash()
            })
        } catch (err) {
            req.flash('errors', err.message)
            return res.redirect('/')
        }
    },
    async getFolder(req, res) {
        try {
            res.render('func/add-folder', {
                pageTitle: 'Fembed - Add Folder',
                message: req.flash()
            })
        } catch (err) {
            req.flash('errors', err.message)
            return res.redirect('/')
        }
    },
    async setSingleFile(req, res) {
        try {
            var { drive_id } = req.body
            if (!drive_id) {
                drive_id = req.query.drive_id
            }
            var isUrl = urlValid(drive_id)
            if (isUrl) {
                drive_id = getDriveId(drive_id)
            }
            if (!drive_id || typeof drive_id !== "string") throw Error('Not found.')
            var isHas = await Drive.findOne({ drive_id })
            if (isHas) {
                return res.send({ success: false, message: "Your file has been added." })
            }
            var access_token = await getAccessToken()
            options = {
                url: 'https://www.googleapis.com/drive/v3/files/' + drive_id + '?alt=json&supportsTeamDrives=true&fields=*',
                method: 'GET',
                headers: {
                    'Authorization': 'Bearer ' + access_token
                }
            }
            var request = await axios(options).catch(err => {
                throw Error(err.message)
            })
            if (/(folder)/.test(request.data.mimeType)) throw Error('Your file not supported.')
            if (request.data.fileSize > 10737418240) throw Error("Your file big more than 10GB")
            var { name, mimeType } = request.data
            await Drive.create({ drive_id, name, mimeType })
            addWait(drive_id, name, mimeType)
            return res.send({ success: true, message: "Success. You file " + drive_id + " added." })
        } catch (err) {
            res.status(403).send({ success: false, error: err.message })
        }
    },
    async setManyFile(req, res) {
        try {
            var { drive_id } = req.body
            if (!drive_id) {
                drive_id = req.query.drive_id
            }
            if (!drive_id || typeof drive_id !== "string") throw Error('Not found.')
            var driveArray = drive_id.split(/[,\n |]/)
            var access_token = await getAccessToken()
            var count = 0
            for (var drive_id of driveArray) {
                var isUrl = urlValid(drive_id)
                if (isUrl) {
                    drive_id = getDriveId(drive_id)
                }
                if (!drive_id) continue;
                var isHas = await Drive.findOne({ drive_id })
                if (isHas) {
                    continue;
                }
                options = {
                    url: 'https://www.googleapis.com/drive/v3/files/' + drive_id + '?alt=json&supportsTeamDrives=true&fields=*',
                    method: 'GET',
                    headers: {
                        'Authorization': 'Bearer ' + access_token
                    }
                }
                var request = await axios(options).catch(err => {
                    throw Error(err.message)
                })
                if (/(folder)/.test(request.data.mimeType)) continue;
                if (request.data.fileSize > 10737418240) continue;
                count++
                var { name, mimeType } = request.data
                await Drive.create({ drive_id, name, mimeType })
                addWait(drive_id, name, mimeType)
            }
            return res.send({ success: true, message: "You added " + count + " files." })
        } catch (err) {
            res.status(403).send({ success: false, error: err.message })
        }
    },
    async setFolder(req, res) {
        try {
            var { drive_id } = req.body
            if (!drive_id) {
                drive_id = req.query.drive_id
            }
            var isUrl = urlValid(drive_id)
            if (isUrl) {
                drive_id = getDriveId(drive_id)
            }
            if (!drive_id || typeof drive_id !== "string") throw Error('Not found.')
            var access_token = await getAccessToken()
            var files = "id,+fileExtension,+originalFilename,+mimeType,+size"
            options = {
                url: 'https://www.googleapis.com/drive/v3/files?q=%22' + drive_id + '%22+in+parents&fields=files(' + files + ')',
                method: 'GET',
                headers: {
                    'Authorization': 'Bearer ' + access_token
                }
            }
            var requests = await axios(options).catch(err => {
                throw Error(err.message)
            })
            var count = 0
            for (var result of requests.data.files) {
                if (/(folder)/.test(result.mimeType)) continue;
                if (result.fileSize > 10737418240) continue;
                var drive_id = result.id
                var isHas = await Drive.findOne({ drive_id })
                if (isHas) {
                    continue;
                }
                count++
                var name = result.originalFilename
                var { mimeType } = result
                await Drive.create({ drive_id, name, mimeType })
                addWait(drive_id, name, mimeType)
            }
            return res.send({ success: true, message: "You added " + count + " files." })
        } catch (err) {
            res.status(403).send({ success: false, error: err.message })
        }
    }
}