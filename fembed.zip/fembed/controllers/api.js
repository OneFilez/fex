const Drive = require('../models/drive')
const jwt = require('jsonwebtoken')
function jwtSignKey(key) {
    return jwt.sign({ secret_key: key }, process.env.JWTSECRET, {
        expiresIn: "30m"
    })
}

// Export Module
module.exports = {
    // Status
    async checkStatus(req, res) {
        try {
            return res.send({ success: true })
        } catch (err) {
            res.status(403).send({ success: false, error: err.message })
        }
    },
    async getToken(req, res) {
        try {
            var { key } = req.query
            if (!key || key !== process.env.ACCESS_KEY) throw Error('Access denied.')
            var token = jwtSignKey(key)
            return res.send({ success: true, token })
        } catch (err) {
            res.status(404).send({ success: false, error: err.message })
        }
    },
    async getDatas(req, res) {
        try {
            var { drive_id } = req.params
            var result = await Drive.findOne({ drive_id }, { _id: 0, __v: 0 })
            if (result) {
                return res.send({ success: true, result })
            } else {
                throw Error("Not found.")
            }
        } catch (err) {
            res.status(404).send({ success: false, error: err.message })
        }
    }
}